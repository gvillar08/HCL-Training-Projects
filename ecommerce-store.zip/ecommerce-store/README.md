# ShopOnline

DESCRIPTION
	ShopOnline is a ecommerce shopping site. Spring boot + Spring security + Thymeleaf is used to build the application.

VIDEO lINK
	https://youtu.be/Wzo3uE7vOco

PASSWORD
	admin123
	manager123
	user123