package com.info.model;

import java.util.Date;
import java.util.List;


public class Root{
    public int resultCount;
    public List<Result> results;
}