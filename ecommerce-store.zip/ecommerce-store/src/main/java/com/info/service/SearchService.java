package com.info.service;

public class SearchService {

}
